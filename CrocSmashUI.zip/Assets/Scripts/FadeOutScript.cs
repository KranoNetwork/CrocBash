﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeOutScript : MonoBehaviour
{
    float fadeTime;
    float currentDelayTime;
    public float fadeRate;
    public float fadeDelay;
    public float timeInbetween;
    bool fadingIn;
    bool delaying;

    public CanvasGroup CanvasGroup;


    // Start is called before the first frame update
    void Start()
    {

        CanvasGroup = gameObject.GetComponent<CanvasGroup>();
        CanvasGroup.alpha = 0;
        delaying = true;
        if (CanvasGroup == null)
        {
            Debug.LogWarning("Canvas Group is null");


        }

    }

    // Update is called once per frame
    void Update()
    {
        //if (Input.GetKey(KeyCode.S))
        //{
        //    fadingIn = true;
        //}

        if (fadingIn)
        {
            FadeIn();
        }

        if (delaying)
        {
            Delay();
        }
    }

    public void FadeOut()
    {
        CanvasGroup.alpha = 1;


    }

    public void FadeIn()
    {
        fadeTime += fadeRate;
        CanvasGroup.alpha = fadeTime;

        if (fadeTime >= 1)
        {
            fadingIn = false;
        }
    }

    public void Delay()
    {
        currentDelayTime += 1;

        if (currentDelayTime > fadeDelay)
        {
            fadingIn = true;
        }

    }
}
